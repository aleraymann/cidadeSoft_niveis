<?php $__env->startSection("conteudo"); ?>
   <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/lang/pt-br.js"></script>-->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
	<!-- Fullcalendar -->
    <script src="<?php echo e(url("js/fullcalendar/lib/moment.min.js")); ?>"></script>
    <script src="<?php echo e(url("js/fullcalendar/fullcalendar.min.js")); ?>"></script>
    <script src="<?php echo e(url("js/fullcalendar/lang/pt-br.js")); ?>"></script>
    
   

<?php if(session('success_message')): ?>
       <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

      </div>
      <?php endif; ?>
    
      <div class="main-panel">
        <div style="margin-top:60px">
        <div class="ml-2" style="margin-top:60px">
        <a href="<?php echo e(url()->previous()); ?>"  class="btn btn-primary ml-3 mb-1">
    <i class="la la-long-arrow-left"></i></a>
        <!-- Button to Open the Modal -->
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--end container-->    
      </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4 ml-2"></div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Calendário e Eventos
                <div class="btn-group float-right" role="group">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('insere_evento')): ?>
                            <button type="button" class="btn btn-success btn-rounded " data-toggle="modal"
                                data-target="#myModal">
                                <i class='fas fa-plus'></i> Eventos
                            </button>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('visual_evento')): ?>
                    <a href="<?php echo e(url("/Calendario/listar")); ?>" class="btn btn-primary btn-rounded ml-2" style="color:white">Ver Eventos</a>
                    <?php endif; ?>
                    </div>
                </h4>

                <?php echo $__env->make("modals.modal_evento", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
           
            <div class="card-body">
               <div id="calendar" class="calendar"> 
              
                    <?php echo $calendar->calendar(); ?>

                    <?php echo $calendar->script(); ?>

                
               </div>
                    
            </div>
           
        </div>
    </div>

  
</div>
<?php $__env->stopSection(); ?>


<!--validação-->
<script>
    // Exemplo de JavaScript inicial para desativar envios de formulário, se houver campos inválidos.
    (function () {
        'use strict';
        window.addEventListener('load', function () {
            // Pega todos os formulários que nós queremos aplicar estilos de validação Bootstrap personalizados.
            var forms = document.getElementsByClassName('needs-validation');
            // Faz um loop neles e evita o envio
            var validation = Array.prototype.filter.call(forms, function (form) {
                form.addEventListener('submit', function (event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();

</script>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>