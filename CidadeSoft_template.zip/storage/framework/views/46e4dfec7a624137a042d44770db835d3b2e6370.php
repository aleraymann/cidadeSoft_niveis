<?php $__env->startSection("conteudo"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<?php if(session('success_message')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

    </div>
<?php endif; ?>

<div class="main-panel">

    <div class="ml-2" style="margin-top:60px">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary ml-3 mb-1">
    <i class="la la-long-arrow-left"></i>
        </a>
        <!-- Button to Open the Modal -->
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--end container-->
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4 ml-2"></div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Usuários
                    <!--<button type="button" class="btn btn-success btn-rounded float-right ml-2" data-toggle="modal"
                        data-target="#myModalUser">
                        <i class='fas fa-plus'></i> Usuários
                    </button>-->
                  
                    <button type="button" class="btn btn-success btn-rounded float-right" data-toggle="modal"
                        data-target="#myModal">
                        Atribuir Cargos
                    </button>
                </h4>
                <?php echo $__env->make("modals.modal_user", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make("modals.modal_role_user", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <th class="">Código</th>
                                <th class="">Imagem</th>
                                <th class="">Usuário</th>
                                <th class="">Email</th>
                                <th class="">Empresa</th>
                                <th class="">Cod Adm</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class=""> <?php echo e($u->id); ?> </td>
                                    <td>
                                    <?php if($u->image != null): ?>
                                    <img src="<?php echo e(url("storage/users/{$u->image}")); ?>" style="max-width:50px; height:50px">
                            <?php else: ?>
                                <img src="<?php echo e(url("img/profile.jpg")); ?>" style="max-width:50px; height:50px" alt="Img Profile" >
                            <?php endif; ?>
                                  
                                    </td>
                                    <td class=""> <?php echo e($u->name); ?> </td>
                                    <td class=""> <?php echo e($u->email); ?> </td>
                                    <td class="">
                                        <?php echo e($u->empresa !== null?" Funcionario(Empresa:  $u->empresa)": "Adm"); ?>

                                    </td>
                                    <td class=""> <?php echo e($u->adm); ?> </td>
                                    <td class="">
                                        <div class="btn-group" role="group">
                                        <a href='<?php echo e(url("/User/editar/$u->id")); ?>'
                                                    class="btn btn-success"><i class='far fa-edit'></i></a>
                                            <a href='<?php echo e(url("/User/vizualizar/$u->id")); ?>'
                                                class="btn btn-primary"><i class='flaticon-lock-1'></i></a>
                                                <a href="javascript:deletarRegistro('<?php echo e($u->id); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                        </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(url("js/core/jquery.3.2.1.min.js")); ?>"></script>
<script>
    function deletarRegistro(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("User/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

</script>
<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>