<?php $__env->startSection("conteudo"); ?>
<div class="main-panel" style="margin-top:60px">
<a href="<?php echo e(url("/Cadastro/funcionarios")); ?>" class="btn btn-primary ml-3 mb-1">
    <i class="la la-long-arrow-left"></i>
    </a>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">
                 <?php echo e($funcionario->Nome); ?><br>
                </h4>
                <div class="btn-group" role="group">
        <a href='<?php echo e(url("/Funcionario/editar/$funcionario->Codigo")); ?>'
            class="btn btn-success"><i class='far fa-edit'></i></a>
        <a href='<?php echo e(url("/Funcionario/excluir/$funcionario->Codigo")); ?>'
            class="btn btn-danger" onclick="return confirm('Deseja mesmo Excluir?')"><i
                class='fas fa-trash-alt'></i></a>
    </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Dados do Funcionário</th>
                                <th class="">Dados de Endereço</th>
                                <th class="">Dados do Usuário</th>
                                <th class="">Dados do Vendedor</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>
                                    <b class="ls-label-text">Nome:</b>
                                    <label><?php echo e($funcionario->Nome); ?> </label><br>
                                    <b class="ls-label-text">CPF:</b>
                                    <label><?php echo e($funcionario->CPF); ?> </label><br>
                                    <b class="ls-label-text">RG:</b>
                                    <label><?php echo e($funcionario->RG); ?> </label><br>
                                    <b class="ls-label-text">Telefone:</b>
                                    <label><?php echo e($funcionario->Telefone); ?> </label><br>
                                    <b class="ls-label-text">Celular:</b>
                                    <label><?php echo e($funcionario->Celular); ?> </label><br>
                                    <b class="ls-label-text">Email:</b>
                                    <label><?php echo e($funcionario->Email); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Endereço:</b>
                                    <label><?php echo e($funcionario->Endereco); ?> </label><br>
                                    <b class="ls-label-text">Bairro:</b>
                                    <label><?php echo e($funcionario->Bairro); ?> </label><br>
                                    <b class="ls-label-text">Cidade:</b>
                                    <label><?php echo e($funcionario->Cidade); ?> </label><br>
                                    <b class="ls-label-text">Estado:</b>
                                    <label><?php echo e($funcionario->Estado); ?> </label><br>
                                    <b class="ls-label-text">Cep:</b>
                                    <label><?php echo e($funcionario->CEP); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Nome do Usuário:</b>
                                    <label><?php echo e($funcionario->Usuario); ?> </label><br>
                                    <b class="ls-label-text">Numero de Identificação:</b>
                                    <label><?php echo e($funcionario->idmsgs); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Comissão de Venda:</b>
                                    <label><?php echo e($funcionario->ComiVend); ?> </label><br>
                                    <b class="ls-label-text">Comissão de Seriços:</b>
                                    <label><?php echo e($funcionario->ComiServ); ?> </label><br>
                                    <b class="ls-label-text">Limite desc à vista:</b>
                                    <label><?php echo e($funcionario->LimDescPV); ?> </label><br>
                                    <b class="ls-label-text">Limite desc à Prazo:</b>
                                    <label><?php echo e($funcionario->LimDescPP); ?> </label><br>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>