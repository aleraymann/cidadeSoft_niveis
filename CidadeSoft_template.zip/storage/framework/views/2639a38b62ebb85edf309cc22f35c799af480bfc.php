<?php $__env->startSection("conteudo"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
<script type="text/javascript">
    jQuery(function ($) {
        $("#Numero_Rem").mask("99999999999");
        $("#Cod_Conv").mask("99999999999");

    });

</script>
<?php if(session('success_message')): ?>
       <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

      </div>
      <?php endif; ?>
    
      <div class="main-panel">
        <div style="margin-top:60px">
        <!-- Button to Open the Modal -->
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--end container-->    
      </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4 ml-2"></div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Remessas
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('insere_boletoRem')): ?>
                    <button type="button" class="btn btn-success btn-rounded float-right" data-toggle="modal"
                        data-target="#myModal">
                        <i class='fas fa-plus'></i> Remessa
                    </button>
                <?php endif; ?>
                </h4>

                <?php echo $__env->make("modals.modal_boleto_remessa", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <th class="">Cod</th>
                                <th class="">Data</th>
                                <th class="">Hora</th>
                                <th class="">Número da Remessa</th>
                                <th class="">Convênio de Cobrança</th>
                                <th class="">Caminho do Arquivo</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $boleto_remessa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remessa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_boletoRem', $remessa)): ?>
                                <tr>
                                    <td> <?php echo e($remessa->Codigo); ?> </td>
                                    <td> <?php echo e($remessa->Data); ?> </td>
                                    <td> <?php echo e($remessa->Hora); ?> </td>
                                    <td> <?php echo e($remessa->Numero_Rem); ?> </td>
                                    <td> <?php echo e($remessa->Cod_Conv); ?> </td>
                                    <td> <?php echo e($remessa->Arquivo); ?> </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edita_boletoRem')): ?>
                                            <a href='<?php echo e(url("/Boleto_remessa/editar/$remessa->Codigo")); ?>'
                                                class="btn btn-success "><i class='far fa-edit'></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleta_boletoRem')): ?>
                                                <a href="javascript:deletarRegistro('<?php echo e($remessa->Codigo); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                        <?php endif; ?>
                                        </div>
                                    </td>

                                </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php echo e($boleto_remessa->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>


<!--validação-->
<script>
    // Exemplo de JavaScript inicial para desativar envios de formulário, se houver campos inválidos.
    (function () {
        'use strict';
        window.addEventListener('load', function () {
            // Pega todos os formulários que nós queremos aplicar estilos de validação Bootstrap personalizados.
            var forms = document.getElementsByClassName('needs-validation');
            // Faz um loop neles e evita o envio
            var validation = Array.prototype.filter.call(forms, function (form) {
                form.addEventListener('submit', function (event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();

</script>
<script src="<?php echo e(url("js/core/jquery.3.2.1.min.js")); ?>"></script>
<script>
    function deletarRegistro(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("Boleto_remessa/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

</script>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>