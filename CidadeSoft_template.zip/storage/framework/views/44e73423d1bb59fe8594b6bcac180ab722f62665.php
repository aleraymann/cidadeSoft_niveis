<?php $__env->startSection("conteudo"); ?>

<?php if(session('success_message')): ?>
       <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

      </div>
      <?php endif; ?>
      <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="main-panel" style="margin-top:60px">
<a href="<?php echo e(url("/Cadastro/transportadoras")); ?>" class="btn btn-primary ml-3 mb-1">
        <i class="la la-long-arrow-left"></i>
    </a>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">
                    <?php echo e($transportadora->Nome_Fantasia); ?>

                </h4>
                <div class="btn-group" role="group">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edita_transp')): ?>
        <a href='<?php echo e(url("/Transportadora/editar/$transportadora->Codigo")); ?>'
            class="btn btn-success"><i class='far fa-edit'></i></a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleta_transp')): ?>
        <a href='<?php echo e(url("/Transportadora/excluir/$transportadora->Codigo")); ?>'
            class="btn btn-danger" onclick="return confirm('Deseja mesmo Excluir?')"><i
                class='fas fa-trash-alt'></i></a>
            <?php endif; ?>  
    </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Dados da Transportadora</th>
                                <th>Dados de Endereço</th>
                                <th>Dados de Frete</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>
                                    <b class="ls-label-text">Nome Fantasia:</b>
                                    <label><?php echo e($transportadora->Nome_Fantasia); ?> </label><br>
                                    <b class="ls-label-text">Razão Social:</b>
                                    <label><?php echo e($transportadora->Razao_Social); ?> </label><br>
                                    <b class="ls-label-text">CPF:</b>
                                    <label><?php echo e($transportadora->CPF); ?> </label><br>
                                    <b class="ls-label-text">RG:</b>
                                    <label><?php echo e($transportadora->RG); ?> </label><br>
                                    <b class="ls-label-text">inscrição Estadual:</b>
                                    <label><?php echo e($transportadora->IE); ?> </label><br>
                                    <b class="ls-label-text">CNPJ:</b>
                                    <label><?php echo e($transportadora->CNPJ); ?> </label><br>
                                    <b class="ls-label-text">Telefone:</b>
                                    <label><?php echo e($transportadora->Telefone); ?> </label><br>
                                    <b class="ls-label-text">Celular:</b>
                                    <label><?php echo e($transportadora->Celular); ?> </label><br>
                                    <b class="ls-label-text">Telefone Comercial:</b>
                                    <label><?php echo e($transportadora->Comercial); ?> </label><br>
                                    <b class="ls-label-text">Email:</b>
                                    <label><?php echo e($transportadora->Email); ?> </label><br>
                                    <b class="ls-label-text">Tipo:</b>
                                    <label><?php echo e($transportadora->Tipo=="F"? "Física":"Jurídica"); ?>

                                    </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Endereço:</b>
                                    <label><?php echo e($transportadora->Endereco); ?> </label><br>
                                    <b class="ls-label-text">Bairro:</b>
                                    <label><?php echo e($transportadora->Bairro); ?> </label><br>
                                    <b class="ls-label-text">Cidade:</b>
                                    <label><?php echo e($transportadora->Cidade); ?> </label><br>
                                    <b class="ls-label-text">Estado:</b>
                                    <label><?php echo e($transportadora->Estado); ?> </label><br>
                                    <b class="ls-label-text">CEP:</b>
                                    <label><?php echo e($transportadora->CEP); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Tipo de Frete:</b>
                                    <label><?php echo e($transportadora->Tipo_Frete=="KM"?"Kilometragem":"Destino"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Frete por M :</b>
                                    <label><?php echo e($transportadora->FreteM); ?> </label><br>
                                    <b class="ls-label-text">Frete por M<sup>2</sup> :</b>
                                    <label><?php echo e($transportadora->FreteM2); ?> </label><br>
                                    <b class="ls-label-text">Frete por M<sup>3</sup> :</b>
                                    <label><?php echo e($transportadora->FreteM3); ?> </label><br>
                                    <b class="ls-label-text">Frete por:</b>
                                    <label><?php echo e($transportadora->FretePor=="K"?"Kilometragem":"Destino"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Cod. Empresa:</b>
                                    <label><?php echo e($transportadora->Empresa); ?> </label><br>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <br>
    <h5 class="ml-2">Dados Adicionais</h5>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('insere_transp')): ?>
    <ul class="nav nav-tabs ml-3" role="tablist">
        <li class="nav-item">
            <a class="nav-link " href="#destino" role="tab" data-toggle="tab"><b> + Destino</b></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#valor" role="tab" data-toggle="tab"> <b>+ Valor</b></a>
        </li>
    </ul>

    <!-- Tab panes -->
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane fade" id="destino">
            <div class="container">
                <?php echo $__env->make("modals.modal_transp_destino", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div role="tabpanel" class="tab-pane fade" id="valor">
            <div class="container">
                <?php echo $__env->make("modals.modal_transp_valor", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Destinos:</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Cidade</th>
                                <th>UF</th>
                                <th>Índice para Cobrança</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $transportadora_destino; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transportadora_destino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $transportadora_destino->Cod_Transp == $transportadora->Codigo ): ?>
                                    <tr>
                                        <td><?php echo e($transportadora_destino->Destino_Cidade); ?></td>
                                        <td><?php echo e($transportadora_destino->Destino_UF); ?></td>
                                        <td><?php echo e($transportadora_destino->Indice); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edita_transp')): ?>
                                                <a href='<?php echo e(url("/Transportadora/destino/editar/$transportadora_destino->Codigo")); ?>'
                                                    class="btn btn-success"><i class='far fa-edit'></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleta_transp')): ?>
                                                    <a href="javascript:deletarDestino('<?php echo e($transportadora_destino->Codigo); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                            <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Valores:</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>KM Inicial</th>
                                <th>KM Final</th>
                                <th>Índice para Cobrança</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $transportadora_valor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transportadora_valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $transportadora_valor->Cod_Transp == $transportadora->Codigo ): ?>
                                    <tr>
                                        <td><?php echo e($transportadora_valor->KmIni); ?></td>
                                        <td><?php echo e($transportadora_valor->KmFim); ?></td>
                                        <td><?php echo e($transportadora_valor->Indice_v); ?></td>
                                        
                                        <td>
                                            <div class="btn-group" role="group">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edita_transp')): ?>
                                                <a href='<?php echo e(url("/Transportadora/valor/editar/$transportadora_valor->Codigo")); ?>'
                                                    class="btn btn-success"><i class='far fa-edit'></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleta_transp')): ?>
                                                    <a href="javascript:deletarValor('<?php echo e($transportadora_valor->Codigo); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                            </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
    function TestaCPF(strCPF) {
        var Soma;
        var Resto;
        Soma = 0;
        if (strCPF == "00000000000") return false;
        if (strCPF == "11111111111") return false;
        if (strCPF == "22222222222") return false;
        if (strCPF == "33333333333") return false;
        if (strCPF == "44444444444") return false;
        if (strCPF == "55555555555") return false;
        if (strCPF == "66666666666") return false;
        if (strCPF == "77777777777") return false;
        if (strCPF == "88888888888") return false;
        if (strCPF == "99999999999") return false;

        for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
        Resto = (Soma * 10) % 11;

        if ((Resto == 10) || (Resto == 11)) Resto = 0;
        if (Resto != parseInt(strCPF.substring(9, 10))) return false;

        Soma = 0;
        for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
        Resto = (Soma * 10) % 11;

        if ((Resto == 10) || (Resto == 11)) Resto = 0;
        if (Resto != parseInt(strCPF.substring(10, 11))) return false;
        return true;
    }
    alert(TestaCPF(strCPF));

    function validarCNPJ(el) {
        if (!_cnpj(el.value)) {

            alert("CNPJ inválido! - " + el.value);

            // apaga o valor
            el.value = "";
        } else {
            //trata se for valido
            alert("Valido");
        }
    }

    function validarCPF(el) {
        if (!TestaCPF(el.value)) {

            alert("CPF inválido! - " + el.value);

            // apaga o valor
            el.value = "";
        } else {
            //trata se for valido
            alert("Valido");
        }
    }

</script>
<script src="<?php echo e(url("js/core/jquery.3.2.1.min.js")); ?>"></script>
<script>
    function deletarDestino(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("Transportadora/destino/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

    function deletarValor(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("Transportadora/valor/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

</script>
<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>