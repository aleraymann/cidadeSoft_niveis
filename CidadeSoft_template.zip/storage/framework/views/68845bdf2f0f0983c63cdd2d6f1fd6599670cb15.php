<!-- The Modal -->
<div class="modal" id="myModal">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Atribuiçao de Cargos</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <?php if(!isset($id)): ?>
                    <form method="post" class="needs-validation" novalidate
                        action="<?php echo e(url("/Role_user/salvar")); ?>">
                    <?php else: ?>
                        <form method="post" action="<?php echo e(url("/Role_user/salvar/$id")); ?>"
                            enctype="multipart/form-data">
                <?php endif; ?>

                <div class="form-row">
                    <div class="form-group col-lg-6">
                        <b class="ls-label-text" for="name">Cargo:</b>
                        <select class="form-control input-border-bottom" id="role_id" name="role_id">
                            <option value="0">Selecione</option>
                            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group col-lg-6">
                        <b class="ls-label-text" for="label">Usuário:</b>
                        <select class="form-control input-border-bottom" id="user_id" name="user_id">
                            <option value="0">Selecione</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                </div>
                <div class="form-row">

                    <?php echo e(csrf_field()); ?>

                    <button class="btn btn-success">Cadastrar</button>
                    <input class="btn btn-secondary ml-5" id="reset" type='reset' value='Limpar Campos' />
                    </form>
                </div>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">

                <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar Formulário</button>
            </div>
        </div>
    </div>
</div>
