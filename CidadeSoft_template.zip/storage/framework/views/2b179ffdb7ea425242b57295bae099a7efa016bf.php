<?php $__env->startSection("conteudo"); ?>
<div class="main-panel" style="margin-top:60px">
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary ml-3 mb-1">
    <i class="la la-long-arrow-left"></i>
    </a>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">
                    Num do Título no Sistema: <?php echo e($boleto_titulo->Nro_Doc); ?>

                </h4>
                <div class="btn-group" role="group">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edita_boletoTit')): ?>
        <a href='<?php echo e(url("/Boleto_titulo/editar/$boleto_titulo->Codigo")); ?>'
            class="btn btn-success"><i class='far fa-edit'></i></a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edita_boletoTit')): ?>
        <a href='<?php echo e(url("/Boleto_titulo/excluir/$boleto_titulo->Codigo")); ?>'
            class="btn btn-danger" onclick="return confirm('Deseja mesmo Excluir?')"><i
                class='fas fa-trash-alt'></i></a>
            <?php endif; ?>
    </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Dados do Boleto</th>
                                <th class="">Mensagens e Instruções</th>
                                <th class="">Multa, Juros, Acrescimo e Desconto</th>
                                <th class="">Dados do Adicionais</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>
                                    <b class="ls-label-text">Baixa/Envio:</b>
                                    <label><?php echo e($boleto_titulo->Sel==1?"Sim":"Não"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Código da Conta:</b>
                                    <label><?php echo e($boleto_titulo->Cod_Conta); ?> </label><br>
                                    <b class="ls-label-text">Data do Documento:</b>
                                    <label><?php echo e($boleto_titulo->Data_Doc); ?> </label><br>
                                    <b class="ls-label-text">Vencimento:</b>
                                    <label><?php echo e($boleto_titulo->Vencimento); ?> </label><br>
                                    <b class="ls-label-text">Numero do Documento no Sistema:</b>
                                    <label><?php echo e($boleto_titulo->Nro_Doc); ?> </label><br>
                                    <b class="ls-label-text">Número do Título no Banco:</b>
                                    <label><?php echo e($boleto_titulo->Nosso_Num); ?> </label><br>
                                    <b class="ls-label-text">Valor:</b>
                                    <label><?php echo e($boleto_titulo->Valor); ?> </label><br>
                                    <b class="ls-label-text">Data Baixa:</b>
                                    <label><?php echo e($boleto_titulo->Data_Bai); ?> </label><br>
                                    <b class="ls-label-text">Data Liquidação:</b>
                                    <label><?php echo e($boleto_titulo->Data_Liq); ?> </label><br>
                                    <b class="ls-label-text">Situaçao:</b>
                                    <?php if( $boleto_titulo->Situacao =="C" ): ?>
                                        <label><?php echo e($boleto_titulo->Situacao = "Carteira"); ?>

                                        </label><br>
                                            <?php elseif( $boleto_titulo->Situacao =="B" ): ?>
                                        <label><?php echo e($boleto_titulo->Situacao = "Baixado"); ?>

                                        </label><br>
                                            <?php elseif( $boleto_titulo->Situacao =="L" ): ?>
                                        <label><?php echo e($boleto_titulo->Situacao = "Liquidado"); ?>

                                        </label><br>
                                    <?php else: ?>
                                        <label><?php echo e($boleto_titulo->Situacao = "Vencido"); ?>

                                        </label><br>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <b class="ls-label-text">Mensagem a ser Impressa 1:</b>
                                    <label><?php echo e($boleto_titulo->Msg_1); ?> </label><br>
                                    <b class="ls-label-text">Mensagem a ser Impressa 3:</b>
                                    <label><?php echo e($boleto_titulo->Msg_2); ?> </label><br>
                                    <b class="ls-label-text">Mensagem a ser Impressa 3:</b>
                                    <label><?php echo e($boleto_titulo->Msg_3); ?> </label><br>
                                    <b class="ls-label-text">Instrução de cobrança 1:</b>
                                    <label><?php echo e($boleto_titulo->Inst_1); ?> </label><br>
                                    <b class="ls-label-text">Instrução de cobrança 2:</b>
                                    <label><?php echo e($boleto_titulo->Inst_2); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Multa:</b>
                                    <label><?php echo e($boleto_titulo->Multa); ?> </label><br>
                                    <b class="ls-label-text">Juros:</b>
                                    <label><?php echo e($boleto_titulo->Taxa_Juros); ?> </label><br>
                                    <b class="ls-label-text">Acréscimo:</b>
                                    <label><?php echo e($boleto_titulo->Acrescimo); ?> </label><br>
                                    <b class="ls-label-text">Desconto:</b>
                                    <label><?php echo e($boleto_titulo->Desconto); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Cod Cliente:</b>
                                    <label><?php echo e($boleto_titulo->Cod_CliFor); ?> </label><br>
                                    <b class="ls-label-text">Cod NF:</b>
                                    <label><?php echo e($boleto_titulo->Cod_NF); ?> </label><br>
                                    <b class="ls-label-text">Cod Contas a Receber:</b>
                                    <label><?php echo e($boleto_titulo->Cod_CtaRec); ?> </label><br>
                                    <b class="ls-label-text">Cod Remessa:</b>
                                    <label><?php echo e($boleto_titulo->Cod_Rem); ?> </label><br>
                                    <b class="ls-label-text">Transação:</b>
                                    <label><?php echo e($boleto_titulo->Transacao); ?> </label><br>
                                    <b class="ls-label-text">Cod. Empresa:</b>
                                    <label><?php echo e($boleto_titulo->Empresa); ?> </label><br>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>