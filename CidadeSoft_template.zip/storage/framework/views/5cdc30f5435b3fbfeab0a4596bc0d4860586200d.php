<?php $__env->startSection("conteudo"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
<script type="text/javascript">
    jQuery(function ($) {
        $("#Comi_Operad").mask("9.99");
        $("#Tx_Antecip").mask("9.99");
    });

</script>


<div class="main-panel" style="margin-top:60px">
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary  btn-rounded">
        Voltar
    </a>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">
                    Edição de Forma de Pagamento
                </h4>
            </div>
            <div class="card-body">
                <div class="modal-body">
                    <?php if(!isset($id)): ?>
                        <form method="post" class="needs-validation" novalidate
                            action="<?php echo e(url("/Forma/salvar")); ?>">
                        <?php else: ?>
                            <form method="post" action="<?php echo e(url("/Forma/salvar/$id")); ?>"
                                enctype="multipart/form-data">
                    <?php endif; ?>
                    <div class="form-row">
                        <div class="form-group col-lg-4">
                            <b class="ls-label-text" for="Descricao	">Descrição:</b>
                            <input type="text" class="form-control  input-border-bottom" name="Descricao" id="Descricao"
                                placeholder="" required minlength="2" maxlength="45"
                                value="<?php echo e(isset($form_pag->Descricao) ? $form_pag->Descricao : ''); ?> ">
                            <div class="invalid-feedback">
                                Por favor, Mínimo 2 caracteres!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-3">
                            <b class="ls-label-text" for="Comi_Operad">Comissão a ser paga:</b>
                            <input type="text" class="form-control input-border-bottom" name="Comi_Operad"
                                id="Comi_Operad" minlength="3" required
                                value="<?php echo e(isset($form_pag->Comi_Operad) ? $form_pag->Comi_Operad : ''); ?> ">
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-3">
                            <b class="ls-label-text" for="Tx_Antecip">Tava de antecip. de Crédito:</b>
                            <input type="text" class="form-control input-border-bottom" name="Tx_Antecip"
                                id="Tx_Antecip" minlength="3" required
                                value="<?php echo e(isset($form_pag->Tx_Antecip) ? $form_pag->Tx_Antecip : ''); ?> ">
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-2">
                            <b class="ls-label-text" for="Tipo">Código:</b>
                            <select class="form-control input-border-bottom" id="Tipo" name="Tipo">
                                <option
                                    value="<?php echo e(isset($form_pag->Tipo) ? $form_pag->Tipo : ''); ?> ">
                                    <?php if( $form_pag->Tipo=="DI"): ?>
                                        Dinheiro
                                    <?php elseif( $form_pag->Tipo =="CH"): ?>
                                        Cheque
                                    <?php elseif( $form_pag->Tipo =="CC"): ?>
                                        Cartão de Crédito
                                    <?php elseif( $form_pag->Tipo =="CD"): ?>
                                        Cartão de Débito
                                    <?php elseif( $form_pag->Tipo =="BO"): ?>
                                        Boleto
                                    <?php else: ?>
                                        Duplicata Mercantil
                                    <?php endif; ?>
                                </option>
                                <option value="DI">Dinheiro</option>
                                <option value="CH">Cheque</option>
                                <option value="CC">Cartão de Crédito</option>
                                <option value="CD">Cartào de Débito</option>
                                <option value="BO">Boleto</option>
                                <option value="DM">Duplicata Mercantil</option>
                            </select>
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-4">
                            <b class="ls-label-text" for="Destino">Destino do Pagamento:</b>
                            <select class="form-control input-border-bottom" id="Destino" name="Destino">
                                <option
                                    value="<?php echo e(isset($form_pag->Destino) ? $form_pag->Destino : ''); ?> ">
                                    <?php if( $form_pag->Destino=="BC"): ?>
                                        <?php echo e($form_pag->Destino = "Banco"); ?>

                                    <?php elseif( $form_pag->Destino =="CX"): ?>
                                        <?php echo e($form_pag->Destino = "Caixa"); ?>

                                    <?php else: ?>
                                        <?php echo e($form_pag->Destino= "Contas"); ?>

                                    <?php endif; ?>
                                </option>
                                <option value="CX">Caixa</option>
                                <option value="BC">Banco</option>
                                <option value="CT">Contas</option>
                            </select>
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-3">
                            <b class="ls-label-text" for="Dest_CliFor">Cli/For de Destino:</b>
                            <input type="text" class="form-control input-border-bottom" name="Dest_CliFor"
                                id="Dest_CliFor" minlength="3"
                                value="<?php echo e(isset($form_pag->Dest_CliFor) ? $form_pag->Dest_CliFor : ''); ?> ">
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                    </div>

                    <div class="form-row">

                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-success">Salvar</button>
                        </form>
                        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                        <script type="text/javascript">
                            $('input').on("keypress", function (e) {
                                /* ENTER PRESSED*/
                                if (e.keyCode == 13) {
                                    /* FOCUS ELEMENT */
                                    var inputs = $(this).parents("form").eq(0).find(":input");
                                    var idx = inputs.index(this);

                                    if (idx == inputs.length - 1) {
                                        inputs[0].select()
                                    } else {
                                        inputs[idx + 1].focus(); //  handles submit buttons

                                    }
                                    return false;
                                }
                            });

                        </script>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>