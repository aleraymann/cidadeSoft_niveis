<?php $__env->startSection("conteudo"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<div class="main-panel" style="margin-top:60px">
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-rounded">
        Voltar
    </a>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">
                    Edição de Evento
                </h4>
            </div>
            <div class="card-body">
                <!-- Modal body -->
                <div class="modal-body">
                    <?php if(!isset($id)): ?>
                        <form method="post" class="needs-validation" novalidate
                            action="<?php echo e(url("/Calendario/salvar")); ?>">
                        <?php else: ?>
                            <form method="post" action="<?php echo e(url("/Calendario/update/$id")); ?>"
                                enctype="multipart/form-data">
                    <?php endif; ?>
                    <div class=" form-row">
                        <div class="form-group col-lg-3">
                            <b class="ls-label-text" for="cor">Cor de destaque:</b>
                            <input type="color" class="form-control input-border-bottom" name="cor" id="cor"
                            value="<?php echo e(isset($events->cor) ? $events->cor : ''); ?>">
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-4">
                         <select class="form-control input-border-bottom" id="cod_usuario" name="cod_usuario" required>
                             <option value="">Selecione o Responável</option>
                             <option value="<?php echo e(Auth::user()->id); ?>"><?php echo e(Auth::user()->name); ?></option>
                             <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $u->adm == Auth::user()->id ): ?>
                                    <option value="<?php echo e($u->id); ?>" <?php echo e($events->cod_usuario == $u->id ? "selected" : ""); ?>><?php echo e($u->name); ?></option>
                                 <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                         <div class="invalid-feedback">
                             Por favor, Campo Obrigatório!
                         </div>
                         <div class="valid-feedback">
                             Tudo certo!
                         </div>
                     </div>
                    </div>
                    <div class="form-row">
                    <div class="form-group col-lg-4">
                            <b class="ls-label-text" for="evento">Titulo do evento:</b>
                            <input type="text" class="form-control input-border-bottom" name="evento" id="evento"
                                minlength="3" maxlength="20" value="<?php echo e(isset($events->evento) ? $events->evento : ''); ?>">
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-3">
                            <b class="ls-label-text" for="data_inicio">Data de Início:</b>
                            <input type="date" class="form-control input-border-bottom" name="data_inicio" id="data_inicio"
                                required  value="<?php echo e($events->data_inicio); ?>">
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-3">
                            <b class="ls-label-text" for="data_fim">Data de Fim:</b>
                            <input type="date" class="form-control input-border-bottom" name="data_fim" id="data_fim"
                                required value="<?php echo e(isset($events->data_fim) ? $events->data_fim : ''); ?>">
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>


                    </div>

                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                    <script type="text/javascript">
                        $('input').on("keypress", function (e) {
                            /* ENTER PRESSED*/
                            if (e.keyCode == 13) {
                                /* FOCUS ELEMENT */
                                var inputs = $(this).parents("form").eq(0).find(":input");
                                var idx = inputs.index(this);

                                if (idx == inputs.length - 1) {
                                    inputs[0].select()
                                } else {
                                    inputs[idx + 1].focus(); //  handles submit buttons

                                }
                                return false;
                            }
                        });

                    </script>
                    <div class="form-row">

                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-success">Salvar</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>