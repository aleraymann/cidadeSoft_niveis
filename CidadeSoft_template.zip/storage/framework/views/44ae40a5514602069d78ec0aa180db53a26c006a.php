<?php $__env->startSection("conteudo"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<?php if(session('success_message')): ?>
       <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

      </div>
      <?php endif; ?>
    
      <div class="main-panel">
        <div style="margin-top:60px">
        <a href="<?php echo e(url("/Calendario")); ?>" class="btn btn-primary ml-3 mb-1">
    <i class="la la-long-arrow-left"></i>
    </a>
        <!-- Button to Open the Modal -->
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--end container-->    
      </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4 ml-2"></div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Listagem de Eventos
                </h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <th class="">Cod</th>
                                <th class="">Cod do Responsável</th>
                                <th class="">Evento </th>
                                <th class="">Data de Início</th>
                                <th class="">Data de Término</th>
                                <th class="">Cod Adm</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_eventos', $e)): ?>
                                <tr>
                                    <td class=""> <?php echo e($e->id); ?> </td>
                                    <td class=""> <?php echo e($e->cod_usuario); ?> </td>
                                    <td class=""> <?php echo e($e->evento); ?> </td>
                                    <td class=""> <?php echo e($e->data_inicio); ?> </td>
                                    <td class=""> <?php echo e($e->data_fim); ?> </td>
                                    <td class=""> <?php echo e($e->user_id); ?> </td>
                                    <td class="">
                                        <div class="btn-group" role="group">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edita_evento')): ?>
                                            <a href=<?php echo e(url("/Calendario/editar/$e->id")); ?>

                                                class="btn btn-success"><i class='far fa-edit'></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleta_evento')): ?>
                                                <a  href="javascript:deletarRegistro('<?php echo e($e->id); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                        <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
      
    </div>
</div>





<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800 ml-2">CEST </h1>
    <button type="button" class="btn btn-success mr-5 mt-20  btn-rounded" data-toggle="modal" data-target="#myModal">
        <i class='fas fa-plus'></i> CEST
    </button>


</div>

<table class="table-sm table-bordered table-hover table-responsive text-center">
    <tr>

    </tr>


</table>
</div>
<?php $__env->stopSection(); ?>

<script src="<?php echo e(url("js/core/jquery.3.2.1.min.js")); ?>"></script>
<script>
    function deletarRegistro(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("Calendario/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

</script>
<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>