<?php $__env->startSection("conteudo"); ?>
<?php if(session('success_message')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

    </div>
<?php endif; ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="main-panel" style="margin-top:60px">
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary  btn-rounded">
        Voltar
    </a>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4>Meu Perfil</h4>
                <a href="<?php echo e(url("/User/edit_profile")); ?>" class="btn btn-success">
                    <i class='lg far fa-edit'></i>
                </a>
            </div>
            <table>
                <tr>
                    <th>
                        <div>
                            <?php if(auth()->user()->image != null): ?>
                                <img src="<?php echo e(url('storage/users/'.auth()->user()->image)); ?>"
                                    style="max-width:200px; height:200px; border-radius:5px" alt="image profile" class="ml-2 mt-2 mb-2">
                            <?php else: ?>
                                <img src="<?php echo e(url("img/profile.jpg")); ?>"
                                    style="max-width:100px; max-height:200px" alt="Img Profile">
                            <?php endif; ?>

                        </div>
                    </th>
                    <th>
                        <div class="card-body">
                        <?php if( Auth::user()->hasAnyRoles('s_adm') ||  Auth::user()->hasAnyRoles('adm')): ?>
                            <p> Nome: <?php echo e(Auth::user()->name); ?></p>
                            <p> Código de Identificação: <?php echo e(Auth::user()->id); ?></p>
                            <p> Email: <?php echo e(Auth::user()->email); ?></p>
                        <?php else: ?>
                            <p> Nome: <?php echo e(Auth::user()->name); ?></p>
                            <p> Código de Identificação: <?php echo e(Auth::user()->id); ?></p>
                            <p> Email: <?php echo e(Auth::user()->email); ?></p>   
                            <p> Administrador Resposável: <?php echo e(Auth::user()->adm); ?></p>
                        <?php endif; ?>
                        </div>
                    </th>
                </tr>
            </table>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>