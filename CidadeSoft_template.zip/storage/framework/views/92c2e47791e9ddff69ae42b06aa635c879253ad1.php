<?php $__env->startSection("conteudo"); ?>
<?php if(session('success_message')): ?>
       <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

      </div>
      <?php endif; ?>
      <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="main-panel" style="margin-top:60px">
    <a href="<?php echo e(url()->previous()); ?>"class="btn btn-primary ml-3 mb-1">
    <i class="la la-long-arrow-left"></i>
    </a>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Conta: <?php echo e($contacadastro->CC); ?>-<?php echo e($contacadastro->Digito); ?> 
                <br> Banco: <?php echo e($contacadastro->Nome_Banco); ?></h4>
                <div class="btn-group " role="group">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edita_conta')): ?>
        <a href='<?php echo e(url("/Conta/editar/$contacadastro->Codigo")); ?>'
            class="btn btn-success"><i class='far fa-edit'></i></a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleta_conta')): ?>
        <a href='<?php echo e(url("/Conta/excluir/$contacadastro->Codigo")); ?>' class="btn btn-danger"
            onclick="return confirm('Deseja mesmo Excluir?')"><i class='fas fa-trash-alt'></i></a>
            <?php endif; ?>
    </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Dados da Conta</th>
                                <th>Dados Adicionais</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>

                                <td>
                                    <b class="ls-label-text">Descrição:</b>
                                    <label><?php echo e($contacadastro->Descricao); ?> </label><br>
                                    <b class="ls-label-text">Número do Banco:</b>
                                    <label><?php echo e($contacadastro->Cod_Banco); ?> </label><br>
                                    <b class="ls-label-text">Dígito do Banco:</b>
                                    <label><?php echo e($contacadastro->Dig_Banco); ?> </label><br>
                                    <b class="ls-label-text">Nome do Banco:</b>
                                    <label><?php echo e($contacadastro->Nome_Banco); ?> </label><br>
                                    <b class="ls-label-text">Número do Banco Cobrador:</b>
                                    <label><?php echo e($contacadastro->Cod_Banco_Cob); ?> </label><br>
                                    <b class="ls-label-text">Dígito do Banco Cobrador:</b>
                                    <label><?php echo e($contacadastro->Dig_Banco_Cob); ?> </label><br>
                                    <b class="ls-label-text">Município:</b>
                                    <label><?php echo e($contacadastro->Praca); ?> </label><br>
                                    <b class="ls-label-text">Agência:</b>
                                    <label><?php echo e($contacadastro->Cod_Age); ?>-<?php echo e($contacadastro->Dig_Age); ?> </label><br>
                                    <b class="ls-label-text">Conta:</b>
                                    <label><?php echo e($contacadastro->CC); ?>-<?php echo e($contacadastro->Digito); ?> </label><br>
                                    <b class="ls-label-text">Tipo da Conta:</b>
                                    <label><?php echo e($contacadastro->Tipo_Conta=="C"?"Caixa":"Banco"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Tipo da Cobrança:</b>
                                    <label><?php echo e($contacadastro->Tipo_Cobranca); ?> </label><br>
                                    <b class="ls-label-text">Códido do Cedente do Boleto:</b>
                                    <label><?php echo e($contacadastro->Cod_Cedente); ?> </label><br>
                                    <b class="ls-label-text">Número de Convenio de Cobrança:</b>
                                    <label><?php echo e($contacadastro->Convenio); ?> </label><br>
                                    <b class="ls-label-text">Número de Carteira de Cobrança:</b>
                                    <label><?php echo e($contacadastro->Carteira); ?> </label><br>
                                    <b class="ls-label-text">Código de Uso do Banco:</b>
                                    <label><?php echo e($contacadastro->Uso_Bco); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Código da Moeda:</b>
                                    <label><?php echo e($contacadastro->Cod_Moeda); ?> </label><br>
                                    <b class="ls-label-text">Espécie da Moeda:</b>
                                    <label><?php echo e($contacadastro->Especie); ?> </label><br>
                                    <b class="ls-label-text">Espécie de Documento:</b>
                                    <label><?php echo e($contacadastro->Especie_Doc); ?> </label><br>
                                    <b class="ls-label-text">Aceite de Cobrança:</b>
                                    <label><?php echo e($contacadastro->Aceite=="S"?"Sim":"Não"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Local de Pagamento:</b>
                                    <label><?php echo e($contacadastro->Local_Pgto); ?> </label><br>
                                    <b class="ls-label-text">Dias a conceder Desconto:</b>
                                    <label><?php echo e($contacadastro->Dias_Desc); ?> </label><br>
                                    <b class="ls-label-text">Percentual de Desconto:</b>
                                    <label><?php echo e($contacadastro->Perc_Desc); ?> </label><br>
                                    <b class="ls-label-text">Percentual de Multa:</b>
                                    <label><?php echo e($contacadastro->Perc_Multa); ?> </label><br>
                                    <b class="ls-label-text">Percentual de juros:</b>
                                    <label><?php echo e($contacadastro->Perc_Juros); ?> </label><br>
                                    <b class="ls-label-text">Dias para avisar no boleto de Protesto:</b>
                                    <label><?php echo e($contacadastro->Dias_AvisoProt); ?> </label><br>
                                    <b class="ls-label-text">Dias a enviar a protesto:</b>
                                    <label><?php echo e($contacadastro->Dias_Prot); ?> </label><br>
                                    <b class="ls-label-text">Taxa de emissão do Boleto:</b>
                                    <label><?php echo e($contacadastro->Tx_Emissao); ?> </label><br>
                                    <b class="ls-label-text">Cod. Empresa:</b>
                                    <label><?php echo e($contacadastro->Empresa); ?> </label><br>
                                </td>

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('insere_saldo')): ?>
    <ul class="nav nav-tabs ml-3" role="tablist">
        <li class="nav-item">
            <a class="nav-link " href="#saldo" role="tab" data-toggle="tab"><b>+ Saldo</b> </a>
        </li>
    </ul>

    <!-- Tab panes -->
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane fade" id="saldo">
            <div class="container">
                <?php echo $__env->make('modals.modal_conta_saldo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="col-md-12">
        <div class="card">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('visual_saldo')): ?>
            <div class="card-header">
                <h4 class="card-title">Saldo</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Dados da Conta:</th>
                                <th>Dados da Transaçao:</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $contasaldo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contasaldo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $contasaldo->Cod_Conta == $contacadastro->Codigo ): ?>
                                    <tr>

                                        <td>
                                            <b><label for="">Data:</b> <?php echo e($contasaldo->Data); ?></label><br>
                                            <?php if($contasaldo->Turno==1): ?>
                                                <b><label for="">Turno:</b> Manhã</label><br>
                                            <?php elseif($contasaldo->Turno==2): ?>
                                                <b><label for="">Turno:</b> Tarde</label><br>
                                            <?php else: ?>
                                                <b><label for="">Turno:</b> Noite</label><br>
                                            <?php endif; ?>
                                            <b><label for="">Saldo Inicial:</b>
                                            <?php echo e($contacadastro->Especie); ?><?php echo e($contasaldo->Saldo_Inicial); ?></label>
                                            <br>
                                            <b><label for="">Salto Total:</b>
                                            <?php echo e($contacadastro->Especie); ?><?php echo e($contasaldo->Saldo_Final); ?></label><br>
                                            <?php if($contasaldo->Situacao=="A"): ?>
                                                <b><label for="">Situação:</b> Aberto</label><br>
                                                <blade
                                                    elseif|(%24contasaldo-%3ESituacao%3D%3D%26%2334%3BX%26%2334%3B)%0D />
                                                <b><label for="">Situação:</b> Ausente</label><br>
                                            <?php else: ?>
                                                <b><label for="">Situação:</b> Fechado</label><br>
                                            <?php endif; ?>
                                            <b><label for="">Empresa:</b> <?php echo e($contasaldo->Empresa); ?></label> <br>
                                            <b><label for="">Funcionário:</b> <?php echo e($contasaldo->Cod_Fun); ?></label> <br>

                                        </td>
                                        <td>
                                            <b><label for="">Total de Entrada:</b>
                                            <?php echo e($contacadastro->Especie); ?><?php echo e($contasaldo->Total_Ent); ?></label> <br>
                                            <b><label for="">Total de Saída:</b>
                                            <?php echo e($contacadastro->Especie); ?><?php echo e($contasaldo->Total_Sai); ?></label><br>
                                            <b><label for="">Total Movimentado em Dinheiro:</b>
                                            <?php echo e($contacadastro->Especie); ?><?php echo e($contasaldo->Total_Dinheiro); ?></label>
                                            <br>
                                            <b><label for="">Total Movimentado em Cartão:</b>
                                            <?php echo e($contacadastro->Especie); ?><?php echo e($contasaldo->Total_Cartao); ?></label><br>
                                            <b><label for="">Total Movimentado em Cheque:</b>
                                            <?php echo e($contacadastro->Especie); ?><?php echo e($contasaldo->Total_Cheque); ?></label>
                                            <br>
                                            <b><label for="">Total Movimentado em Duplicata:</b>
                                            <?php echo e($contacadastro->Especie); ?><?php echo e($contasaldo->Total_Duplicata); ?></label>
                                        </td>
                                        <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleta_saldo')): ?>
                                            <div class="btn-group" role="group">
                                            <a href="javascript:deletarSaldo('<?php echo e($contasaldo->Codigo); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                            </div>
                                        <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>



</div>
<script src="<?php echo e(url("js/core/jquery.3.2.1.min.js")); ?>"></script>
<script>
    function deletarSaldo(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("Conta/saldo/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>