<?php $__env->startSection("conteudo"); ?>
<?php if(session('success_message')): ?>
       <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

      </div>
      <?php endif; ?>
      <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="main-panel" style="margin-top:60px">
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary  btn-rounded">
        Voltar
    </a>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">
                    <?php if( $clifor->Tip=="C"): ?>
                        Cliente:
                    <?php elseif( $clifor->Tip=="F"): ?>
                        Fornecedor:
                    <?php else: ?>
                        Cliente e Fornecedor:
                    <?php endif; ?>
                    <?php echo e($clifor->Nome_Fantasia); ?>


                </h4>
                <div class="btn-group " role="group">
                    <a href='<?php echo e(url("/Clifor/editar/$clifor->Codigo")); ?>'
                        class="btn btn-success"><i class='far fa-edit'></i></a>
                    <a href='<?php echo e(url("/Clifor/excluir/$clifor->Codigo")); ?>'
                        class="btn btn-danger" onclick="return confirm('Deseja mesmo Excluir?')"><i
                            class='fas fa-trash-alt'></i></a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Dados</th>
                                <th>Tipo e Perfil</th>
                                <th>Financeiro e Movimentação</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>
                                    <b class="ls-label-text">Nome Fantasia:</b>
                                    <label><?php echo e($clifor->Nome_Fantasia); ?> </label><br>
                                    <b class="ls-label-text">Razão Social:</b>
                                    <label><?php echo e($clifor->Razao_Social); ?> </label><br>
                                    <b class="ls-label-text">Estado Civil:</b>
                                    <?php if( $clifor->Estado_Civil=="C"): ?>
                                        <label><?php echo e($clifor->Estado_Civil = "Casado"); ?>

                                        </label><br>
                                    <?php elseif( $clifor->Estado_Civil=="S"): ?>
                                        <label><?php echo e($clifor->Estado_Civil = "Solteiro"); ?>

                                        </label><br>
                                    <?php elseif( $clifor->Estado_Civil=="D"): ?>
                                        <label><?php echo e($clifor->Estado_Civil = "Divorciado"); ?>

                                        </label><br>
                                    <?php elseif( $clifor->Estado_Civil=="V"): ?>
                                        <label><?php echo e($clifor->Estado_Civil = "Viúvo"); ?>

                                        </label><br>
                                    <?php else: ?>
                                        <label><?php echo e($clifor->Estado_Civil = ""); ?> </label><br>
                                    <?php endif; ?>
                                    <b class="ls-label-text">Sexo:</b>
                                    <label><?php echo e($clifor->Sexo=="M"? "Masculino":"Feminino"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Situação:</b>
                                    <label><?php echo e($clifor->Ativo==1? "Ativo":"Inativo"); ?>

                                    </label><br>
                                    <b class="ls-label-text">CPF:</b>
                                    <label><?php echo e($clifor->CPF); ?> </label><br>
                                    <b class="ls-label-text">RG:</b>
                                    <label><?php echo e($clifor->RG); ?> </label><br>
                                    <b class="ls-label-text">CNPJ:</b>
                                    <label><?php echo e($clifor->CNPJ); ?> </label><br>
                                    <b class="ls-label-text">Telefone</b>
                                    <label>(<?php echo e($clifor->Operadora1); ?>) - <?php echo e($clifor->Telefone); ?> </label><br>
                                    <b class="ls-label-text">Celular</b>
                                    <label>(<?php echo e($clifor->Operadora2); ?>) - <?php echo e($clifor->Celular); ?> </label><br>
                                    <b class="ls-label-text">Telefone Comercial ou FAX</b>
                                    <label>(<?php echo e($clifor->Operadora3); ?>) - <?php echo e($clifor->Comercial); ?> </label><br>
                                    <b class="ls-label-text">Email:</b>
                                    <label><?php echo e($clifor->Email); ?> </label><br>
                                    <b class="ls-label-text">Site:</b>
                                    <label><?php echo e($clifor->Site); ?> </label><br>
                                    <b class="ls-label-text">Profissao:</b>
                                    <label><?php echo e($clifor->Profissao); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Tipo de Cliente(Fisico/Jurídico):</b>
                                    <label><?php echo e($clifor->Fis_Jur=="F"?"Física":"Jurídica"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Tipo:Cliente/Fornecedor):</b>
                                    <?php if( $clifor->Tip=="C"): ?>
                                        <label><?php echo e($clifor->Tip = "Cliente"); ?> </label><br>
                                    <?php elseif( $clifor->Tip=="F"): ?>
                                        <label><?php echo e($clifor->Tip = "Fornecedor"); ?>

                                        </label><br>
                                    <?php else: ?>
                                        <label><?php echo e($clifor->Tip = "Ambos"); ?> </label><br>
                                    <?php endif; ?>
                                    <b class="ls-label-text">Atacadista?</b>
                                    <label><?php echo e($clifor->Cli_Atacado==1?"Sim":"Não"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Perfil do Cliente/Fornecedor:</b>
                                    <label><?php echo e($clifor->Perfil); ?> </label><br>
                                    <b class="ls-label-text">Inscrição Municipal:</b>
                                    <label><?php echo e($clifor->IM); ?> </label><br>
                                    <b class="ls-label-text">Inscrição Estadual:</b>
                                    <label><?php echo e($clifor->IE); ?> </label><br>
                                    <b class="ls-label-text">Inscricao Estadual do Substituto Tributario:</b>
                                    <label><?php echo e($clifor->IEST); ?> </label><br>
                                    <b class="ls-label-text">Classe ABC:</b>
                                    <label><?php echo e($clifor->Class_ABC); ?> </label><br>
                                    <b class="ls-label-text">Situação Financeira:</b>
                                    <label><?php echo e($clifor->SitFinanc=="L"?"Livre":"Bloqueado"); ?>

                                    </label><br>
                                    <b class="ls-label-text">Data do Cadastro:</b>
                                    <label><?php echo e($clifor->Data_Cadastro); ?> </label><br>
                                </td>
                                <td>
                                    <b class="ls-label-text">Limite de Crédito:</b>
                                    <label><?php echo e($clifor->LimiCred); ?> </label><br>
                                    <b class="ls-label-text">Percentual de Desconto ou Acrescimo nos valores:</b>
                                    <label><?php echo e($clifor->PercDescAcresc); ?> </label><br>
                                    <b class="ls-label-text">Cod. Vendedor:</b>
                                    <label><?php echo e($clifor->Vendedor); ?> </label><br>
                                    <b class="ls-label-text">Cod. Empresa:</b>
                                    <label><?php echo e($clifor->Empresa); ?> </label><br>
                                    <b class="ls-label-text">Ultima Movimentação:</b>
                                    <?php if( $clifor->Local_UltMov=="PED"): ?>
                                        <label><?php echo e($clifor->Local_UltMov = "Pedido"); ?>

                                        </label><br>
                                    <?php elseif( $clifor->Local_UltMov=="OS"): ?>
                                        <label><?php echo e($clifor->Local_UltMov = "Ordem de Serviço"); ?>

                                        </label><br>
                                    <?php else: ?>
                                        <label><?php echo e($clifor->Local_UltMov = "Nota Fiscal"); ?>

                                        </label><br>
                                    <?php endif; ?>
                                    <b class="ls-label-text">Data da Ultima Movimentação:</b>
                                    <label><?php echo e($clifor->Data_UltMov); ?> </label><br>
                                    <b class="ls-label-text">Observaões sobre o cliente:</b>
                                    <label><?php echo e($clifor->Observacoes); ?> </label><br>
                                    <b class="ls-label-text">Aviso ao Cliente/Fornecedor:</b>
                                    <label><?php echo e($clifor->Aviso); ?> </label><br>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <h5 class="ml-2">Dados Adicionais</h5>
    <ul class="nav nav-tabs ml-3" role="tablist">
        <li class="nav-item">
            <a class="nav-link " href="#contato" role="tab" data-toggle="tab"><b> + Contato</b></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#endereco" role="tab" data-toggle="tab"><b> + Endereço</b></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#referencia" role="tab" data-toggle="tab"><b>+ Referência</b></a>
        </li>
    </ul>

    <!-- Tab panes -->
    <div class="tab-content ">
        <div role="tabpanel" class="tab-pane fade" id="contato">
            <div class="container">
                <?php echo $__env->make("modals.modal_clifor_contato", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div role="tabpanel" class="tab-pane fade" id="endereco">
            <div class="container">
                <?php echo $__env->make("modals.modal_clifor_endereco", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div role="tabpanel" class="tab-pane fade" id="referencia">
            <div class="container">
                <?php echo $__env->make("modals.modal_clifor_referencia", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Contatos Adicionados:</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Telefone</th>
                                <th>Tipo</th>
                                <th>Setor</th>
                                <th>Data Nascimento</th>
                                <th>RG</th>
                                <th>CPF</th>
                                <th>Email</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $clifor_contato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clifor_contato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $clifor_contato->Cod_CliFor == $clifor->Codigo ): ?>
                                    <tr>
                                        <td><?php echo e($clifor_contato->Nome); ?></td>
                                        <td><?php echo e($clifor_contato->Celular); ?></td>
                                        <td><?php echo e($clifor_contato->Tipo); ?></td>
                                        <td><?php echo e($clifor_contato->Setor); ?></td>
                                        <td><?php echo e($clifor_contato->Data_Nasc); ?></td>
                                        <td><?php echo e($clifor_contato->RG); ?></td>
                                        <td><?php echo e($clifor_contato->CPF); ?></td>
                                        <td><?php echo e($clifor_contato->Email); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href='<?php echo e(url("/Clifor/contato/editar/$clifor_contato->Codigo")); ?>'
                                                    class="btn btn-success"><i class='far fa-edit'></i></a>
                                                    <a href="javascript:deletarContato('<?php echo e($clifor_contato->Codigo); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Endereços Adicionados:</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>CEP</th>
                                <th>Tipo de Endereco</th>
                                <th>Endereco</th>
                                <th>Numero</th>
                                <th>Bairro</th>
                                <th>Complemento</th>
                                <th>Ponto de Referencia</th>
                                <th>Cod_IBGE</th>
                                <th>Cidade</th>
                                <th>Estado</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $clifor_endereco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clifor_endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $clifor_endereco->Cod_CliFor == $clifor->Codigo ): ?>
                                    </tr>
                                    <tr>
                                        <td><?php echo e($clifor_endereco->CEP); ?></td>
                                       
                                        <?php if( $clifor_endereco->Tipo_Endereco=="C"): ?>
                                            <td><?php echo e($clifor_endereco->Tipo_Endereco = "Correspondência"); ?>

                                            </td>
                                            <?php elseif( $clifor_endereco->Tipo_Endereco=="E"): ?>
                                            <td><?php echo e($clifor_endereco->Tipo_Endereco = "Entrega"); ?>

                                            </td>
                                        <?php else: ?>
                                            <td><?php echo e($clifor_endereco->Tipo_Endereco = "Ambos"); ?>

                                            </td>
                                        <?php endif; ?>
                                        <td><?php echo e($clifor_endereco->Endereco); ?></td>
                                        <td><?php echo e($clifor_endereco->Numero); ?></td>
                                        <td><?php echo e($clifor_endereco->Bairro); ?></td>
                                        <td><?php echo e($clifor_endereco->Complemento); ?></td>
                                        <td><?php echo e($clifor_endereco->Ponto_Referencia); ?></td>
                                        <td><?php echo e($clifor_endereco->Cod_IBGE); ?></td>
                                        <td><?php echo e($clifor_endereco->Cidade); ?></td>
                                        <td><?php echo e($clifor_endereco->Estado); ?></td>

                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href='<?php echo e(url("/Clifor/endereco/editar/$clifor_endereco->Codigo")); ?>'
                                                    class="btn btn-success"><i class='far fa-edit'></i></a>
                                                    <a href="javascript:deletarEndereco('<?php echo e($clifor_endereco->Codigo); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Referências cadastradas:</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover ">
                        <thead>
                            <tr>
                                <th>Loja / Banco</th>
                                <th>Conta</th>
                                <th>Telefone</th>
                                <th>Data da última Compra</th>
                                <th>Valor da última Compra</th>
                                <th>Limite</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $clifor_referencia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clifor_referencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $clifor_referencia->Cod_CliFor == $clifor->Codigo ): ?>
                                    <tr>
                                        <td><?php echo e($clifor_referencia->Loja_Banco); ?></td>
                                        <td><?php echo e($clifor_referencia->Conta); ?></td>
                                        <td><?php echo e($clifor_referencia->Telefone); ?></td>
                                        <td><?php echo e($clifor_referencia->Ult_Compra); ?></td>
                                        <td><?php echo e($clifor_referencia->Valor_UltCompra); ?></td>
                                        <td><?php echo e($clifor_referencia->Limite); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href='<?php echo e(url("/Clifor/referencia/editar/$clifor_referencia->Codigo")); ?>'
                                                    class="btn btn-success"><i class='far fa-edit'></i></a>
                                                    <a href="javascript:deletarReferencia('<?php echo e($clifor_referencia->Codigo); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
    function TestaCPF(strCPF) {
        var Soma;
        var Resto;
        Soma = 0;
        if (strCPF == "00000000000") return false;
        if (strCPF == "11111111111") return false;
        if (strCPF == "22222222222") return false;
        if (strCPF == "33333333333") return false;
        if (strCPF == "44444444444") return false;
        if (strCPF == "55555555555") return false;
        if (strCPF == "66666666666") return false;
        if (strCPF == "77777777777") return false;
        if (strCPF == "88888888888") return false;
        if (strCPF == "99999999999") return false;

        for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
        Resto = (Soma * 10) % 11;

        if ((Resto == 10) || (Resto == 11)) Resto = 0;
        if (Resto != parseInt(strCPF.substring(9, 10))) return false;

        Soma = 0;
        for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
        Resto = (Soma * 10) % 11;

        if ((Resto == 10) || (Resto == 11)) Resto = 0;
        if (Resto != parseInt(strCPF.substring(10, 11))) return false;
        return true;
    }
    alert(TestaCPF(strCPF));

    function validarCNPJ(el) {
        if (!_cnpj(el.value)) {

            alert("CNPJ inválido! - " + el.value);

            // apaga o valor
            el.value = "";
        } else {
            //trata se for valido
            alert("Valido");
        }
    }

    function validarCPF(el) {
        if (!TestaCPF(el.value)) {

            alert("CPF inválido! - " + el.value);

            // apaga o valor
            el.value = "";
        } else {
            //trata se for valido
            alert("Valido");
        }
    }

</script>
<script src="<?php echo e(url("js/core/jquery.3.2.1.min.js")); ?>"></script>
<script>
    function deletarContato(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("Clifor/contato/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

    function deletarEndereco(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("Clifor/endereco/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

    function deletarReferencia(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("Clifor/referencia/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

</script>
<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>