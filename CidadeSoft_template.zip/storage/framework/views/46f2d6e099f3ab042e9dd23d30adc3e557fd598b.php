

<?php if(Session::get("sucesso") != null): ?>
<div class="alert alert-success" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <?php echo e(session::get("sucesso")); ?>

</div>
<?php endif; ?>

<?php if(Session::get("erro") != null): ?>
<div class="alert alert-danger" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <?php echo e(session::get("erro")); ?>

</div>
<?php endif; ?>




