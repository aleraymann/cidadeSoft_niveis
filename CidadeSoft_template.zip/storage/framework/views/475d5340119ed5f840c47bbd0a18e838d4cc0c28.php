<?php $__env->startSection("conteudo"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<div class="main-panel" style="margin-top:60px">
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-rounded">
        Voltar
    </a>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">
                    Edição de CEST
                </h4>
            </div>
            <div class="card-body">
                <!-- Modal body -->
                <div class="modal-body">
                    <?php if(!isset($id)): ?>
                        <form method="post" class="needs-validation" novalidate
                            action="<?php echo e(url("/Cest/salvar")); ?>">
                        <?php else: ?>
                            <form method="post" action="<?php echo e(url("/Cest/salvar/$id")); ?>"
                                enctype="multipart/form-data">
                    <?php endif; ?>
                    <div class="form-row">
                        <div class="form-group col-lg-3">
                            <b class="ls-label-text" for="CEST">CEST:</b>
                            <input type="text" class="form-control input-border-bottom" name="CEST" id="CEST"
                                minlength="3" maxlength="10"
                                value="<?php echo e(isset($cest->CEST) ? $cest->CEST : ''); ?> ">
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-3">
                            <b class="ls-label-text" for="NCM">NCM:</b>
                            <select class="form-control input-border-bottom" required id="NCM" name="NCM">
                                <?php $__currentLoopData = $ncm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ncm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_ncm', $ncm)): ?>
                                    <option value="<?php echo e($ncm->NCM); ?>"
                                        <?php echo e($cest->NCM == $ncm->NCM ? "selected" : ""); ?>>
                                        <?php echo e($ncm->NCM); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">
                                Por favor, Campo Obrigatório!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>
                        <div class="form-group col-lg-6">
                            <b class="ls-label-text" for="Descricao	">Descrição:</b>
                            <input type="text" class="form-control input-border-bottom" name="Descricao" id="Descricao"
                                placeholder="" minlength="5" maxlength="45"
                                value="<?php echo e(isset($cest->Descricao) ? $cest->Descricao : ''); ?> ">
                            <div class="invalid-feedback">
                                Por favor, Mínimo 5 caracteres!
                            </div>
                            <div class="valid-feedback">
                                Tudo certo!
                            </div>
                        </div>

                    </div>

                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                    <script type="text/javascript">
                        $('input').on("keypress", function (e) {
                            /* ENTER PRESSED*/
                            if (e.keyCode == 13) {
                                /* FOCUS ELEMENT */
                                var inputs = $(this).parents("form").eq(0).find(":input");
                                var idx = inputs.index(this);

                                if (idx == inputs.length - 1) {
                                    inputs[0].select()
                                } else {
                                    inputs[idx + 1].focus(); //  handles submit buttons

                                }
                                return false;
                            }
                        });

                    </script>
                    <div class="form-row">

                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-success">Salvar</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>