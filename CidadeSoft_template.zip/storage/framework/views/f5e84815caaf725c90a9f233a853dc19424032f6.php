<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cli_For.pdf</title>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }

        h2,
        h3,
        h4 {
            text-align: center;
        }

        label {
            margin-top: 10px;
            float: right;
        }

    </style>
</head>

<body>
    <div>
        <div>
            <div>
                <table>
                    <thead>
                        <tr>
                            <th>
                                <h2>Cidadesoft_</h2>
                            </th>
                            <th>
                                <label>
                                    Data: <?php echo e(date('d/m/Y')); ?><br>
                                    Hora: <?php echo e(date('H:i:s')); ?></label> </th>
                        </tr>
                        <tr>
                            <th colspan="2">
                                <?php echo e(Auth::user()->name); ?> / <?php echo e(Auth::user()->email); ?>

                            </th>
                        </tr>
                    </thead>
                </table><br>
                <table>
                    <thead>
                        <tr>
                            <th>
                                <h3>Clientes e/ou Fornecedores Cadastrados no Sistema</h3>
                            </th>

                        </tr>
                    </thead>
                </table>
            </div>
            <div>

                <div>
                    <table>
                        <thead>
                            <tr>
                                <th class="">Cod</th>
                                <th class="">Nome Fantasia</th>
                                <th class="">Situação</th>
                                <th class="">Cadastro</th>
                                <th class="">Cliente/Fornecedor</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $clifor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($cf->Codigo); ?> </td>
                                    <td> <?php echo e($cf->Nome_Fantasia); ?> </td>
                                    <td> <?php echo e($cf->Ativo==1? "Ativo":"Inativo"); ?>

                                    </td>
                                    <td> <?php echo e($cf->Data_Cadastro); ?> </td>
                                    <?php if( $cf->Tip=="C"): ?>
                                        <td> <?php echo e($cf->Tip = "Cliente"); ?> </td>
                                    <?php elseif( $cf->Tip=="F"): ?>
                                        <td> <?php echo e($cf->Tip = "Fornecedor"); ?> </td>
                                    <?php else: ?>
                                        <td> <?php echo e($cf->Tip = "Ambos"); ?> </td>
                                    <?php endif; ?>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table><br>
                    <table>
                        <tfoot>
                        <tr>
                            
                            <th>
                            <h4>
                            CIDADESOFT LTDA <br>CNPJ 09.324.429/0001-09
                            </h4>
                            </th>
                            <th>
                           <h4>
                           R. Brg. Rocha, 3028 - Bonsucesso, Guarapuava - PR, CEP: 85035-270
                           </h4> 
                            </th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>

    </div>
</body>

</html>
