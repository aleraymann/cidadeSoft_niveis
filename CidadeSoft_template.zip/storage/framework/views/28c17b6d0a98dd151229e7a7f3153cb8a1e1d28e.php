<?php $__env->startSection("conteudo"); ?>

       <?php if(session('success_message')): ?>
       <div class="alert alert-danger">
        <?php echo e(session('success_message')); ?>

      </div>
      <?php endif; ?>
    
      <div class="main-panel">
        <div style="margin-top:60px">
        <!-- Button to Open the Modal -->
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--end container-->    
      </div>

      <div class="d-sm-flex align-items-center justify-content-between mb-4 ml-2"></div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Categoria para Totalização no Pedido, OS
                    <button type="button" class="btn btn-success btn-rounded float-right" data-toggle="modal"
                        data-target="#myModal">
                        <i class='fas fa-plus'></i> Categoria
                    </button>
                </h4>

                <?php echo $__env->make("modals.modal_categoriaos", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="multi-filter-select" class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <th class="">Cod</th>
                                <th class="">Descricao</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $categoriaos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class=""> <?php echo e($cat->Codigo); ?> </td>
                                    <td class=""> <?php echo e($cat->Descricao); ?> </td>
                                    <td class="">
                                        <div class="btn-group" role="group">
                                            <a href='<?php echo e(url("/CatOSPed/editar/$cat->Codigo")); ?>'
                                                class="btn btn-success"><i class='far fa-edit'></i></a>
                                                <a href="javascript:deletarRegistro('<?php echo e($cat->Codigo); ?>')"
                                                class="btn btn-danger "><i class='fas fa-trash-alt'></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php echo e($categoriaos->links()); ?>

    </div>
</div>
      <?php $__env->stopSection(); ?>


      <!--validação-->    
      <script>
    // Exemplo de JavaScript inicial para desativar envios de formulário, se houver campos inválidos.
    (function() {
      'use strict';
      window.addEventListener('load', function() {
        // Pega todos os formulários que nós queremos aplicar estilos de validação Bootstrap personalizados.
        var forms = document.getElementsByClassName('needs-validation');
        // Faz um loop neles e evita o envio
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
      }, false);
    })();
  </script>

<script src="<?php echo e(url("js/core/jquery.3.2.1.min.js")); ?>"></script>
<script>
    function deletarRegistro(id) {
        var csrf_token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        swal({
            title: "Excluir",
            text: "Excluir do item selecionado?",
            icon: "warning",
            buttons: {
                confirm: {
                    text: 'Sim',
                    className: 'btn btn-success'
                },
                cancel: {
                    text: 'Não',
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url("CatOSPed/excluir")); ?>" + '/' + id,
                    type: 'DELETE',
                    data: {
                        '_method': 'DELETE',
                        '_token': csrf_token
                    },
                    success: function () {
                        location.reload();
                        swal({
                            title: "Registro deletado com sucesso!",
                            icon: "success",
                        });

                    },
                    error: function () {
                        swal("Erro!", "Algo de errado aconteceu!", );
                    }
                });

            }
        });
    }

</script>



<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>